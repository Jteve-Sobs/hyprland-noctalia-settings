source /usr/share/cachyos-fish-config/cachyos-config.fish

# overwrite greeting
# hyfetch statt dem fastfetch aus cachyos-config.fish. Hier statt in der
# Systemdatei, damit es Paket-Updates und den Restore uebersteht.
function fish_greeting
    hyfetch
end
