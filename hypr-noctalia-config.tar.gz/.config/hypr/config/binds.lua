local mainMod = "SUPER"
local noctCall = "noctalia msg "
local launchPrefix = "uwsm app -- " -- if you are not using UWSM, make this empty (e.g. "")

-- AZERTY fix: the number-row keys emit symbols (& é " ' ...) without Shift, so
-- binding to the digit characters fails. Bind by physical keycode instead.
-- Digit d -> evdev keycode: 1..9 => 10..18, 0 => 19
local function digitCode(d)
    return "code:" .. (d == 0 and 19 or (9 + d))
end

-- Descriptions + "-- N. Category" headings feed the Noctalia keybind cheatsheet
-- (noctalia msg panel-toggle kenn/keybind-cheatsheet:cheatsheet).

---------------------------
---- WINDOW MANAGEMENT ----
---------------------------

-- 1. Fenster
hl.bind(mainMod .. " + Escape",      hl.dsp.exec_cmd("hyprctl kill"),                    { description = "Fenster per Klick killen" })
hl.bind(mainMod .. " + Q",           hl.dsp.window.close(),                              { description = "Fenster schließen" })
hl.bind(mainMod .. " + ALT + Space", hl.dsp.window.float({ action = "toggle" }),         { description = "Floating an/aus" })
hl.bind(mainMod .. " + D",           hl.dsp.window.fullscreen({ mode = 1 }),             { description = "Maximieren" })
hl.bind(mainMod .. " + F",           hl.dsp.window.fullscreen(),                         { description = "Vollbild" })
hl.bind(mainMod .. " + J",           hl.dsp.layout("togglesplit"),                       { description = "Split umschalten" })

-- 2. Fokus
hl.bind(mainMod .. " + Left",  hl.dsp.focus({ direction = "left" }),          { description = "Fokus links" })
hl.bind(mainMod .. " + Right", hl.dsp.focus({ direction = "right" }),         { description = "Fokus rechts" })
hl.bind(mainMod .. " + Up",    hl.dsp.focus({ direction = "up" }),            { description = "Fokus oben" })
hl.bind(mainMod .. " + Down",  hl.dsp.focus({ direction = "down" }),          { description = "Fokus unten" })
hl.bind("ALT + Tab",           hl.dsp.window.cycle_next(),                    { description = "Nächstes Fenster" })
hl.bind(mainMod .. " + Tab",   hl.dsp.exec_cmd(noctCall .. "window-switcher"), { description = "Window-Switcher" })

-- 3. Fenster verschieben
hl.bind(mainMod .. " + SHIFT + Up",                   hl.dsp.window.move({ direction = "u" }),        { description = "Fenster nach oben" })
hl.bind(mainMod .. " + SHIFT + Right",                hl.dsp.window.move({ direction = "r" }),        { description = "Fenster nach rechts" })
hl.bind(mainMod .. " + SHIFT + Left",                 hl.dsp.window.move({ direction = "l" }),        { description = "Fenster nach links" })
hl.bind(mainMod .. " + SHIFT + Down",                 hl.dsp.window.move({ direction = "d" }),        { description = "Fenster nach unten" })
hl.bind(mainMod .. " + SHIFT + " .. digitCode(1),     hl.dsp.window.move({ monitor = MONITOR1 }),     { description = "Fenster auf Monitor 1" })
hl.bind(mainMod .. " + SHIFT + " .. digitCode(2),     hl.dsp.window.move({ monitor = MONITOR2 }),     { description = "Fenster auf Monitor 2" })
hl.bind(mainMod .. " + SHIFT + " .. digitCode(3),     hl.dsp.window.move({ monitor = MONITOR3 }),     { description = "Fenster auf Monitor 3" })
hl.bind(mainMod .. " + SHIFT + mouse_up",             hl.dsp.window.move({ monitor   = "-1" }),       { description = "Fenster auf vorherigen Monitor" })
hl.bind(mainMod .. " + SHIFT + mouse_down",           hl.dsp.window.move({ monitor   = "+1" }),       { description = "Fenster auf nächsten Monitor" })
hl.bind(mainMod .. " + CONTROL + SHIFT + Right",      hl.dsp.window.move({ workspace = "m+1" }),      { description = "Fenster auf nächsten Workspace" })
hl.bind(mainMod .. " + CONTROL + SHIFT + Left",       hl.dsp.window.move({ workspace = "m-1" }),      { description = "Fenster auf vorherigen Workspace" })
hl.bind(mainMod .. " + CONTROL + SHIFT + mouse_up",   hl.dsp.window.move({ workspace = "m-1" }),      { description = "Fenster auf vorherigen Workspace" })
hl.bind(mainMod .. " + CONTROL + SHIFT + mouse_down", hl.dsp.window.move({ workspace = "m+1" }),      { description = "Fenster auf nächsten Workspace" })
for i = 1, NUM_WPM do
    local key = i % 10
    hl.bind(mainMod .. " + SHIFT + CONTROL + " .. digitCode(key), hl.dsp.window.move({ workspace = "m~" .. i }),
        { description = "Fenster auf Workspace " .. i })
end
for i = 1, NUM_WPM do
    local key = i % 10
    hl.bind(mainMod .. " + SHIFT + ALT + " .. digitCode(key), hl.dsp.window.move({ workspace = "m~" .. i, follow = false }),
        { description = "Fenster still auf Workspace " .. i })
end

-- 4. Maus & Zoom
hl.bind(mainMod .. " + mouse:272", hl.dsp.window.drag(),   { description = "Fenster ziehen" })
hl.bind(mainMod .. " + mouse:273", hl.dsp.window.resize(), { description = "Fenstergröße ändern" })

local function zoomfunction(value)
    local zoomvalue = hl.get_config("cursor:zoom_factor")
    if (zoomvalue + value) > 3.0 then
        hl.config({ cursor = { zoom_factor = 3.0 } })
    elseif (zoomvalue + value) < 1.0 then
        hl.config({ cursor = { zoom_factor = 1.0 } })
    else
        hl.config({ cursor = { zoom_factor = zoomvalue + value } })
    end
end
hl.bind(mainMod .. " + Minus", function() zoomfunction(-0.3) end, { repeating = true, description = "Zoom raus" })
hl.bind(mainMod .. " + Plus", function() zoomfunction(0.3) end, { repeating = true, description = "Zoom rein" })

--# Zoom with keypad
hl.bind(mainMod .. " + code:82", function() zoomfunction(-0.3) end, { repeating = true, description = "Zoom raus (Numpad)" })
hl.bind(mainMod .. " + code:86", function() zoomfunction(0.3) end, { repeating = true, description = "Zoom rein (Numpad)" })


------------------
---- LAUNCHER ----
------------------

-- 5. Programme
hl.bind(mainMod .. " + Return",     hl.dsp.exec_cmd(launchPrefix .. TERMINAL),              { description = "Terminal" })
hl.bind(mainMod .. " + E",          hl.dsp.exec_cmd(launchPrefix .. FILE_MANAGER),          { description = "Dateimanager" })
hl.bind(mainMod .. " + T",          hl.dsp.exec_cmd(launchPrefix .. EDITOR),                { description = "Texteditor" })
hl.bind(mainMod .. " + C",          hl.dsp.exec_cmd(launchPrefix .. CALCULATOR),            { description = "Taschenrechner" })
hl.bind("XF86Calculator",           hl.dsp.exec_cmd(launchPrefix .. CALCULATOR),            { description = "Taschenrechner" })
hl.bind(mainMod .. " + W",          hl.dsp.exec_cmd(launchPrefix .. BROWSER),               { description = "Browser" })
hl.bind("CONTROL + SHIFT + Escape", hl.dsp.exec_cmd(launchPrefix .. TERMINAL .. " -e btop"), { description = "Taskmanager (btop)" })

-- 6. Noctalia
hl.bind(mainMod .. " + Z",          hl.dsp.exec_cmd(noctCall .. "settings-toggle"),                              { description = "Einstellungen" })
hl.bind(mainMod .. " + X",          hl.dsp.exec_cmd(noctCall .. "panel-toggle control-center"),                  { description = "Control Center" })
hl.bind(mainMod .. " + SUPER_L",    hl.dsp.exec_cmd(noctCall .. "panel-toggle control-center"),                  { release = true, description = "Control Center (Super allein loslassen)" })
hl.bind(mainMod .. " + Space",      hl.dsp.exec_cmd(noctCall .. "panel-toggle launcher"),                        { description = "App-Launcher" })
hl.bind(mainMod .. " + period",     hl.dsp.exec_cmd(noctCall .. "panel-toggle launcher /emo"),                   { description = "Emoji-Picker" })
hl.bind(mainMod .. " + L",          hl.dsp.exec_cmd(noctCall .. "session lock"),                                 { description = "Bildschirm sperren" })
hl.bind(mainMod .. " + ALT + C",    hl.dsp.exec_cmd(noctCall .. "panel-toggle session"),                         { description = "Sitzungsmenü" })
hl.bind(mainMod .. " + F1",         hl.dsp.exec_cmd(noctCall .. "panel-toggle kenn/keybind-cheatsheet:cheatsheet"), { description = "Keybind-Cheatsheet" })

---------------------------
---- HARDWARE CONTROLS ----
---------------------------

-- 7. Audio, Medien & Helligkeit
hl.bind("XF86AudioRaiseVolume", hl.dsp.exec_cmd(noctCall .. "volume-up"),   { locked = true, repeating = true, description = "Lauter" })
hl.bind("XF86AudioLowerVolume", hl.dsp.exec_cmd(noctCall .. "volume-down"), { locked = true, repeating = true, description = "Leiser" })
hl.bind("XF86AudioMute",        hl.dsp.exec_cmd(noctCall .. "volume-mute"), { locked = true, description = "Stumm" })
hl.bind("XF86AudioMicMute",     hl.dsp.exec_cmd(noctCall .. "mic-mute"),    { locked = true, description = "Mikro stumm" })

hl.bind("XF86AudioPlay",  hl.dsp.exec_cmd(noctCall .. "media toggle"),   { locked = true, description = "Play/Pause" })
hl.bind("XF86AudioPause", hl.dsp.exec_cmd(noctCall .. "media toggle"),   { locked = true, description = "Play/Pause" })
hl.bind("XF86AudioNext",  hl.dsp.exec_cmd(noctCall .. "media next"),     { locked = true, description = "Nächster Titel" })
hl.bind("XF86AudioPrev",  hl.dsp.exec_cmd(noctCall .. "media previous"), { locked = true, description = "Vorheriger Titel" })

hl.bind("XF86MonBrightnessUp",   hl.dsp.exec_cmd(noctCall .. "brightness-up"),   { locked = true, repeating = true, description = "Heller" })
hl.bind("XF86MonBrightnessDown", hl.dsp.exec_cmd(noctCall .. "brightness-down"), { locked = true, repeating = true, description = "Dunkler" })

-------------------
---- UTILITIES ----
-------------------

-- 8. Tools
hl.bind(mainMod .. " + P",     hl.dsp.exec_cmd("hyprpicker -a -n"),                     { description = "Farbpipette" })
hl.bind("Print",               hl.dsp.exec_cmd(noctCall .. "screenshot-region"),        { description = "Screenshot Bereich" })
hl.bind(mainMod .. " + Print", hl.dsp.exec_cmd(noctCall .. "screenshot-fullscreen"),    { description = "Screenshot Vollbild" })
hl.bind(mainMod .. " + SHIFT + W", hl.dsp.exec_cmd(noctCall .. "panel-toggle wallpaper"), { description = "Hintergrundbild" })
hl.bind(mainMod .. " + V", hl.dsp.exec_cmd(noctCall .. "panel-toggle clipboard"),       { description = "Zwischenablage" })
hl.bind(mainMod .. " + A", hl.dsp.exec_cmd(noctCall .. "panel-toggle control-center notifications"), { description = "Benachrichtigungen" })

-------------------------------
---- WORKSPACES & MONITORS ----
-------------------------------

-- 9. Workspaces & Monitore
hl.bind(mainMod .. " + " .. digitCode(1), hl.dsp.focus({ monitor = MONITOR1 }), { description = "Monitor 1" })
hl.bind(mainMod .. " + " .. digitCode(2), hl.dsp.focus({ monitor = MONITOR2 }), { description = "Monitor 2" })
hl.bind(mainMod .. " + " .. digitCode(3), hl.dsp.focus({ monitor = MONITOR3 }), { description = "Monitor 3" })

-- Absolute
for i = 1, NUM_WPM do
    local key = i % 10
    hl.bind(mainMod .. " + ALT + " .. digitCode(key), hl.dsp.focus({ workspace = i }),
        { description = "Workspace " .. i .. " (global)" })
end
-- Relative
for i = 1, NUM_WPM do
    local key = i % 10
    hl.bind(mainMod .. " + CONTROL + " .. digitCode(key), hl.dsp.focus({ workspace = "m~" .. i }),
        { description = "Workspace " .. i })
end
-- Relative, ohne Strg (zusätzlich zu Super+Ziffer → Monitor)
for i = 1, NUM_WPM do
    local key = i % 10
    hl.bind(mainMod .. " + " .. digitCode(key), hl.dsp.focus({ workspace = "m~" .. i }),
        { description = "Workspace " .. i })
end

hl.bind(mainMod .. " + CONTROL + Right",       hl.dsp.focus({ workspace = "m+1" }),    { description = "Nächster Workspace" })
hl.bind(mainMod .. " + CONTROL + Left",        hl.dsp.focus({ workspace = "m-1" }),    { description = "Vorheriger Workspace" })
hl.bind(mainMod .. " + CONTROL + Down",        hl.dsp.focus({ workspace = "emptym" }), { description = "Leerer Workspace" })

hl.bind(mainMod .. " + mouse_down",           hl.dsp.focus({ workspace = "m-1" }), { description = "Vorheriger Workspace" })
hl.bind(mainMod .. " + mouse_up",             hl.dsp.focus({ workspace = "m+1" }), { description = "Nächster Workspace" })
hl.bind(mainMod .. " + CONTROL + mouse_up",   hl.dsp.focus({ workspace = "m-1" }), { description = "Vorheriger Workspace" })
hl.bind(mainMod .. " + CONTROL + mouse_down", hl.dsp.focus({ workspace = "m+1" }), { description = "Nächster Workspace" })

hl.bind(mainMod .. " + SHIFT + S", hl.dsp.window.move({ workspace = "special" }), { description = "Fenster ins Scratchpad" })
hl.bind(mainMod .. " + S",         hl.dsp.workspace.toggle_special(),             { description = "Scratchpad an/aus" })
