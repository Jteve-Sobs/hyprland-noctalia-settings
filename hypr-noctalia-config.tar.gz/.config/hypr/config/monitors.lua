-- Monitor-Konfiguration
--
-- Ziel:
--   * Externe Monitore angeschlossen (Dock) -> nur die externen sind aktiv,
--     das Laptopdisplay (eDP-1) wird abgeschaltet.
--   * Keine externen Monitore -> nur das Laptopdisplay ist aktiv.

local LAPTOP = "eDP-1"

-- Wenn kein echter Monitor aktiv ist, legt Hyprland kurzzeitig einen
-- virtuellen Headless-Output namens "FALLBACK" an. Der zaehlt nicht als
-- externer Monitor -- sonst bleibt eDP-1 nach dem Abstecken faelschlich aus.
local IGNORE = { [LAPTOP] = true, ["FALLBACK"] = true }

-- DEBUG: temporaeres Logging zur Fehlersuche. Kann spaeter entfernt werden.
local DEBUG_LOG = "/tmp/claude-1000/monitors_debug.log"
local function dbg(msg)
    local ok, f = pcall(io.open, DEBUG_LOG, "a")
    if ok and f then
        f:write(os.date("%H:%M:%S") .. " " .. msg .. "\n")
        f:close()
    end
end

-- Standardregel fuer alle externen Monitore
hl.monitor({
    output   = "",
    mode     = "preferred",
    position = "auto",
    scale    = 1.0,
})

-- iiyama PL2791Q (DP-1, 2560x1440) steht physisch um 90 Grad nach rechts
-- gedreht (Hochkant) links neben dem 4K-Monitor (DP-3, 3840x2160) und beide
-- sind vertikal mittig zueinander ausgerichtet (nicht an der Oberkante).
--
-- Gedreht ist DP-1 1440 breit x 2560 hoch. DP-3 ist 3840 breit x 2160 hoch.
-- DP-1 steht bei y=0, DP-3 wird um (2560-2160)/2 = 200px nach unten
-- versetzt, damit beide Mittelpunkte auf gleicher Hoehe liegen.
hl.monitor({
    output    = "DP-1",
    mode      = "preferred",
    position  = "0x0",
    scale     = 1.0,
    transform = 1,
})

hl.monitor({
    output   = "DP-3",
    mode     = "preferred",
    position = "1440x200",
    scale    = 1.0,
})

-- Zaehlt die aktuell aktiven externen Monitore.
-- hl.get_monitors() liefert nur aktivierte Ausgaenge, deaktivierte tauchen
-- hier nicht auf -- das Laptopdisplay wird daher explizit herausgefiltert.
local function external_count()
    local count = 0
    local names = {}
    for _, monitor in ipairs(hl.get_monitors()) do
        if not IGNORE[monitor.name] then
            count = count + 1
        end
        names[#names + 1] = monitor.name
    end
    dbg("external_count(): get_monitors() = [" .. table.concat(names, ",") .. "] -> " .. count)
    return count
end

local function apply()
    local want_laptop_on = external_count() == 0
    dbg("apply(): want_laptop_on=" .. tostring(want_laptop_on))

    local ok, err = pcall(function()
        if want_laptop_on then
            -- Keine externen Monitore -> Laptopdisplay an
            hl.monitor({
                output   = LAPTOP,
                disabled = false,
                mode     = "preferred",
                position = "auto",
                scale    = 1.0,
            })
        else
            -- Externe Monitore vorhanden -> Laptopdisplay aus
            hl.monitor({
                output   = LAPTOP,
                disabled = true,
            })
        end

        -- hl.monitor() reiht die Aenderung nur ein; ohne diesen Aufruf wird sie
        -- teils erst beim naechsten ohnehin anstehenden Refresh sichtbar (z.B.
        -- nie, wenn danach kein weiteres Monitor-Event mehr kommt).
        hl.exec_scheduled_prop_refresh_immediately()
    end)

    dbg("apply(): hl.monitor/refresh ok=" .. tostring(ok) .. " err=" .. tostring(err))

    local edp = hl.get_monitor(LAPTOP)
    if edp then
        dbg("apply(): eDP-1 laut get_monitor() jetzt disabled? (kein direktes Feld, siehe monitors-all)")
    else
        dbg("apply(): hl.get_monitor('eDP-1') liefert nil (Monitor deaktiviert/nicht in Liste)")
    end

    return want_laptop_on
end

-- Beim Hotplug feuern die Events, bevor Hyprland die Monitorliste fertig
-- aktualisiert hat, und beim Andocken/Abdocken kommen mehrere Events kurz
-- hintereinander. Deshalb wird die Auswertung entprellt und erst nach einer
-- kurzen Pause auf dem dann stabilen Zustand ausgefuehrt.
local function start_timer(store_in, timeout, cb)
    return hl.timer(function()
        store_in.timer = nil
        cb()
    end, { timeout = timeout, type = "oneshot" })
end

local debounce_box = {}
local verify_box = {}

local function schedule(event_name)
    dbg("schedule() aufgerufen, event=" .. tostring(event_name))

    if debounce_box.timer then
        debounce_box.timer:set_enabled(false)
        debounce_box.timer = nil
    end
    if verify_box.timer then
        verify_box.timer:set_enabled(false)
        verify_box.timer = nil
    end

    debounce_box.timer = start_timer(debounce_box, 500, function()
        dbg("debounce-timer feuert -> apply()")
        local want_laptop_on = apply()

        -- Selbstheilung: kurz danach nochmal pruefen, falls die Monitorliste
        -- beim ersten Durchlauf noch nicht ganz aktuell war (z.B. bei
        -- mehreren Kabeln, die nicht exakt gleichzeitig gezogen werden).
        verify_box.timer = start_timer(verify_box, 1200, function()
            local now_want_laptop_on = external_count() == 0
            dbg("verify-timer: now_want_laptop_on=" .. tostring(now_want_laptop_on) .. " (war " .. tostring(want_laptop_on) .. ")")
            if now_want_laptop_on ~= want_laptop_on then
                dbg("verify-timer: Abweichung erkannt -> erneutes apply()")
                apply()
            end
        end)
    end)
end

hl.on("monitor.added", function() schedule("monitor.added") end)
hl.on("monitor.removed", function() schedule("monitor.removed") end)
hl.on("hyprland.start", function() schedule("hyprland.start") end)
