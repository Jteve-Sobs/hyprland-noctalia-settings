#!/usr/bin/env bash

LAPTOP="eDP-1"

# Alle tatsächlich angeschlossenen externen Displays ermitteln
external_count=$(
    hyprctl monitors all -j |
    jq --arg laptop "$LAPTOP" \
       '[.[] | select(.name != $laptop and .disabled == false)] | length'
)

if (( external_count > 0 )); then
    # Externes Display vorhanden -> Laptopdisplay aus
    hyprctl eval "hl.monitor({ output = \"$LAPTOP\", disabled = true })"
else
    # Kein externes Display -> Laptopdisplay wieder an
    hyprctl eval "hl.monitor({
        output = \"$LAPTOP\",
        disabled = false,
        mode = \"preferred\",
        position = \"auto\",
        scale = 1
    })"
fi